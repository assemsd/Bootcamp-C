int my_abs(int a) {
    int b = abs(a);
    return b;
}