int my_is_negative(int a) {
    if (a < 0) {
        return 0;
    }
    else {
        return 1;
    }
}