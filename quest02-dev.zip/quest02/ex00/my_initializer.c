#include <stdio.h>
void my_initializer(int *a) {
    *a = 0;
}
