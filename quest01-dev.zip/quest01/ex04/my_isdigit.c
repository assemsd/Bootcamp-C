int my_isdigit(char a) {
    if(a >= '0' && a <= '9') {
        return 1;
    }
    else {
        return 0;
    }
}