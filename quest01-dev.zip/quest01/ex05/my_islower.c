int my_islower(char a) {
    if(a >= 'a' && a <= 'z') {
        return 1;
    }
    else {
        return 0;
    }
}