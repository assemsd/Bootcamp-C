int my_isspace(char a) {
    if(a == ' ') {
        return 1;
    }
    else {
        return 0;
    }
}