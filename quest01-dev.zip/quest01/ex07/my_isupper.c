int my_isupper(char a) {
    if(a >= 'A' && a <= 'Z') {
        return 1;
    }
    else {
        return 0;
    }
}