#include <stdio.h>
#include <stdlib.h>

void my_putstr(char* param_1) {

    printf("%s", param_1);
  }